﻿namespace WebApiSelfHostingDemo
{
    public class WebApiSelfHostingDemoConsts
    {
        public const string LocalizationSourceName = "WebApiSelfHostingDemo";
    }
}