﻿using Abp.Authorization;
using WebApiSelfHostingDemo.Authorization.Roles;
using WebApiSelfHostingDemo.MultiTenancy;
using WebApiSelfHostingDemo.Users;

namespace WebApiSelfHostingDemo.Authorization
{
    public class PermissionChecker : PermissionChecker<Tenant, Role, User>
    {
        public PermissionChecker(UserManager userManager)
            : base(userManager)
        {

        }
    }
}
