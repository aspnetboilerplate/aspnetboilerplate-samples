﻿using Abp.MultiTenancy;
using WebApiSelfHostingDemo.Users;

namespace WebApiSelfHostingDemo.MultiTenancy
{
    public class Tenant : AbpTenant<User>
    {
        public Tenant()
        {
            
        }

        public Tenant(string tenancyName, string name)
            : base(tenancyName, name)
        {
        }
    }
}