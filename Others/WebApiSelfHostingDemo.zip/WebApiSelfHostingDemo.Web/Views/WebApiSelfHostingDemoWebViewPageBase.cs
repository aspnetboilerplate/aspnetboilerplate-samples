﻿using Abp.Web.Mvc.Views;

namespace WebApiSelfHostingDemo.Web.Views
{
    public abstract class WebApiSelfHostingDemoWebViewPageBase : WebApiSelfHostingDemoWebViewPageBase<dynamic>
    {

    }

    public abstract class WebApiSelfHostingDemoWebViewPageBase<TModel> : AbpWebViewPage<TModel>
    {
        protected WebApiSelfHostingDemoWebViewPageBase()
        {
            LocalizationSourceName = WebApiSelfHostingDemoConsts.LocalizationSourceName;
        }
    }
}