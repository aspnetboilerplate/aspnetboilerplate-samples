﻿using System.Web.Mvc;

namespace WebApiSelfHostingDemo.Web.Controllers
{
    public class AboutController : WebApiSelfHostingDemoControllerBase
    {
        public ActionResult Index()
        {
            return View();
        }
	}
}