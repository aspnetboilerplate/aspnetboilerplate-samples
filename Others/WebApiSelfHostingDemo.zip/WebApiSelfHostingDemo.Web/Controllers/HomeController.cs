﻿using System.Web.Mvc;
using Abp.Web.Mvc.Authorization;

namespace WebApiSelfHostingDemo.Web.Controllers
{
    [AbpMvcAuthorize]
    public class HomeController : WebApiSelfHostingDemoControllerBase
    {
        public ActionResult Index()
        {
            return View();
        }
	}
}