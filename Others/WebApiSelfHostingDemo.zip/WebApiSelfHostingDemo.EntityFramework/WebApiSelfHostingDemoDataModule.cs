﻿using System.Data.Entity;
using System.Reflection;
using Abp.Modules;
using Abp.Zero.EntityFramework;
using WebApiSelfHostingDemo.EntityFramework;

namespace WebApiSelfHostingDemo
{
    [DependsOn(typeof(AbpZeroEntityFrameworkModule), typeof(WebApiSelfHostingDemoCoreModule))]
    public class WebApiSelfHostingDemoDataModule : AbpModule
    {
        public override void PreInitialize()
        {
            Database.SetInitializer(new CreateDatabaseIfNotExists<WebApiSelfHostingDemoDbContext>());

            Configuration.DefaultNameOrConnectionString = "Default";
        }

        public override void Initialize()
        {
            IocManager.RegisterAssemblyByConvention(Assembly.GetExecutingAssembly());
        }
    }
}
