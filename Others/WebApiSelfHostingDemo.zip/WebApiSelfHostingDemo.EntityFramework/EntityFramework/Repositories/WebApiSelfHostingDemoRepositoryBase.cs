﻿using Abp.Domain.Entities;
using Abp.EntityFramework;
using Abp.EntityFramework.Repositories;

namespace WebApiSelfHostingDemo.EntityFramework.Repositories
{
    public abstract class WebApiSelfHostingDemoRepositoryBase<TEntity, TPrimaryKey> : EfRepositoryBase<WebApiSelfHostingDemoDbContext, TEntity, TPrimaryKey>
        where TEntity : class, IEntity<TPrimaryKey>
    {
        protected WebApiSelfHostingDemoRepositoryBase(IDbContextProvider<WebApiSelfHostingDemoDbContext> dbContextProvider)
            : base(dbContextProvider)
        {

        }

        //add common methods for all repositories
    }

    public abstract class WebApiSelfHostingDemoRepositoryBase<TEntity> : WebApiSelfHostingDemoRepositoryBase<TEntity, int>
        where TEntity : class, IEntity<int>
    {
        protected WebApiSelfHostingDemoRepositoryBase(IDbContextProvider<WebApiSelfHostingDemoDbContext> dbContextProvider)
            : base(dbContextProvider)
        {

        }

        //do not add any method here, add to the class above (since this inherits it)
    }
}
