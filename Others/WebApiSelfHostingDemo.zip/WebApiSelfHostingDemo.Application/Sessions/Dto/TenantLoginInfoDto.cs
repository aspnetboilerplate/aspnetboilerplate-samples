﻿using Abp.Application.Services.Dto;
using Abp.AutoMapper;
using WebApiSelfHostingDemo.MultiTenancy;

namespace WebApiSelfHostingDemo.Sessions.Dto
{
    [AutoMapFrom(typeof(Tenant))]
    public class TenantLoginInfoDto : EntityDto
    {
        public string TenancyName { get; set; }

        public string Name { get; set; }
    }
}