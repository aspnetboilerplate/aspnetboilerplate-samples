using System.Data.Entity;
using System.Reflection;
using Abp.Modules;
using WebApiSelfHostingDemo.EntityFramework;

namespace WebApiSelfHostingDemo.Migrator
{
    [DependsOn(typeof(WebApiSelfHostingDemoDataModule))]
    public class WebApiSelfHostingDemoMigratorModule : AbpModule
    {
        public override void PreInitialize()
        {
            Database.SetInitializer<WebApiSelfHostingDemoDbContext>(null);

            Configuration.BackgroundJobs.IsJobExecutionEnabled = false;
        }

        public override void Initialize()
        {
            IocManager.RegisterAssemblyByConvention(Assembly.GetExecutingAssembly());
        }
    }
}