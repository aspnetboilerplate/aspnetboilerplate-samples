﻿using System;
using System.Reflection;
using System.Web.Http;
using Abp;
using Abp.Configuration.Startup;
using Abp.Modules;
using Abp.WebApi.Configuration;
using Microsoft.Owin.Hosting;
using Owin;
using WebApiSelfHostingDemo.Api;

namespace WebApiSelfHostingDemo.ConsoleHostApp
{
    /* After running the application, send a POST request to http://localhost:9000/api/services/app/session/GetCurrentLoginInformations
    */
    
    class Program
    {
        static void Main(string[] args)
        {
            var baseAddress = "http://localhost:9000/";

            // Start OWIN host 
            using (WebApp.Start<Startup>(url: baseAddress))
            {
                Console.WriteLine("Press ENTER to exit...");
                Console.ReadLine();
            }
        }
    }

    public class Startup
    {
        public void Configuration(IAppBuilder appBuilder)
        {
            var abpBootstrapper = AbpBootstrapper.Create<MyConsoleModule>();
            abpBootstrapper.Initialize();

            var httpConfig = abpBootstrapper.IocManager.Resolve<IAbpWebApiConfiguration>().HttpConfiguration;
            appBuilder.UseWebApi(httpConfig);
        }
    }

    [DependsOn(typeof(WebApiSelfHostingDemoWebApiModule), typeof(WebApiSelfHostingDemoDataModule))]
    public class MyConsoleModule : AbpModule
    {
        public override void PreInitialize()
        {
            Configuration.Modules.AbpWebApi().HttpConfiguration = new HttpConfiguration();
        }

        public override void Initialize()
        {
            IocManager.RegisterAssemblyByConvention(Assembly.GetExecutingAssembly());

            Configuration.Modules.AbpWebApi().HttpConfiguration.Routes.MapHttpRoute(
                name: "DefaultApi",
                routeTemplate: "api/{controller}/{id}",
                defaults: new { id = RouteParameter.Optional }
            );
        }
    }
}
