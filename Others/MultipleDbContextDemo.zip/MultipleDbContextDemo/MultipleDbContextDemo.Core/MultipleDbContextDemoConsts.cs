﻿namespace MultipleDbContextDemo
{
    public class MultipleDbContextDemoConsts
    {
        public const string LocalizationSourceName = "MultipleDbContextDemo";
    }
}